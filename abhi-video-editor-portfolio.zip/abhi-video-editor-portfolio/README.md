# ABHI — YouTube Video Editor Portfolio

A premium, single-page, mobile-first portfolio with **no dependencies, no build step, and no backend required**. The website is ready to deploy as a static site on Vercel.

## Run locally

Open `index.html` in your browser. For a local server (recommended):

```bash
python -m http.server 8000
```

Then visit <http://localhost:8000>.

## Edit your site

Open **`index.html`**. Near the start of the `<script>` tag, edit the **single `CONFIG` object**. Every portfolio text, project, price, testimonial, social link and statistic is defined there.

Before publishing:

1. Replace `email: 'hello@example.com'` with your real address.
2. Replace `links.fiverr`, `links.upwork`, and any other `#` social links with real HTTPS URLs.
3. Replace six demo project titles/images and add your own **11-character YouTube video ID** to each project's `videoId` field. Full standard YouTube URLs also work. Videos load *only when a card is clicked*; until you configure them a helpful demo prompt is shown.
4. Replace the illustrative stats, sample prices, turnaround times, and **placeholder testimonials** with accurate information.
5. Replace the bundled SVG example thumbnails in `assets/` with thumbnails from your actual portfolio. Change `thumbnail`, `hero.poster`, and `beforeAfter.image` in CONFIG as needed. The before/after slider applies a demo color grade to one image; use genuine source material for a real comparison.
6. Update `seo.title` and `seo.description` inside CONFIG. The default HTML `<title>` and meta descriptions in `<head>` should also be kept in sync for non-JavaScript SEO crawlers/social preview parsers.

## Contact form

The contact form deliberately uses `mailto:`. Clicking **Prepare my inquiry** produces an **Open email app** link with a prefilled draft, plus a **Copy the inquiry** alternative. The visitor must press **Send** in their email app. The site does *not* silently deliver or save messages. For submissions directly from the website, connect a service like Formspree or a Vercel serverless function and replace the submit handler.

## Deploy to Vercel

**Option A — from GitHub:** Push this folder into a GitHub repository, import it into Vercel, select **Other** framework, and leave build command empty (static output uses the project root).

**Option B — Vercel CLI:** In the website folder, run:

```bash
npx vercel --prod
```

No package installation or build command required.

## Features

- Responsive hero and mobile navigation
- Six lazy-loaded project thumbnail cards with click-to-play YouTube dialog
- Interactive, keyboard-accessible before/after slider
- Services, editable stats, process, packages and testimonials
- Accessible FAQ accordions
- Form-to-email inquiry workflow
- Basic SEO, reduced-motion support, lazy loading and bundled vector demo artwork
- System-font fallback if Google Fonts are blocked

### Important

All included projects, images, rates, numbers and testimonials are **samples, not claims about real work**. Replace them before making the site public. Sample artworks are custom vector illustrations bundled with the site, not client project screenshots.
